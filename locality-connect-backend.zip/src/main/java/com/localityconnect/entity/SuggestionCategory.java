package com.localityconnect.entity;

public enum SuggestionCategory {
    SUGGESTION,
    COMPLAINT
}
