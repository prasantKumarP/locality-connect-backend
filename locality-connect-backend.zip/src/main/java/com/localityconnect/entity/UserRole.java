package com.localityconnect.entity;

public enum UserRole {
    ADMIN,
    RESIDENT
}
