package com.localityconnect.entity;

public enum SuggestionStatus {
    NEW,
    VALID,
    INVALID,
    LATER,
    IN_DISCUSSION
}
