package com.localityconnect.entity;

public enum VoteType {
    LIKE,
    DISLIKE
}
